# flyteconnector

![Version: v2.0.0](https://img.shields.io/badge/Version-v2.0.0-informational?style=flat-square) ![Type: application](https://img.shields.io/badge/Type-application-informational?style=flat-square)

A Helm chart for Flyte connector

## Values

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| additionalContainers | list | `[]` | Appends additional containers to the deployment spec. May include template values. |
| additionalVolumeMounts | list | `[]` | Appends additional volume mounts to the main container's spec. May include template values. |
| additionalVolumes | list | `[]` | Appends additional volumes to the deployment spec. May include template values. |
| affinity | object | `{}` | affinity for flyteconnector deployment |
| commonAnnotations | object | `{}` |  |
| commonLabels | object | `{}` |  |
| configPath | string | `"/etc/flyteconnector/config/*.yaml"` | Default regex string for searching configuration files |
| connectorSecret.secretData | object | `{}` | Optional Secret manifest fragment to merge into the generated Secret, for example `stringData:` or `data:`. |
| extraArgs | object | `{}` | Appends extra command line arguments to the main command |
| fullnameOverride | string | `""` |  |
| image.pullPolicy | string | `"IfNotPresent"` | Docker image pull policy |
| image.repository | string | `"ghcr.io/flyteorg/flyte-connectors"` | Docker image for flyteconnector deployment |
| image.tag | string | `"latest"` | Docker image tag |
| nameOverride | string | `""` |  |
| nodeSelector | object | `{}` | nodeSelector for flyteconnector deployment |
| podAnnotations | object | `{}` | Annotations for flyteconnector pods |
| podEnv | object | `{}` | Additional flyteconnector pod container environment variables |
| podLabels | object | `{}` | Labels for flyteconnector pods |
| podSecurityContext | object | `{}` |  |
| ports.containerPort | int | `8000` |  |
| ports.name | string | `"connector-grpc"` |  |
| priorityClassName | string | `""` | Sets priorityClassName for flyteconnector pod(s). |
| rbac | object | `{"enabled":false,"rules":[{"apiGroups":[""],"resources":["secrets"],"verbs":["get"]}]}` | RBAC configuration for flyteconnector Enable to allow the connector to read secrets across namespaces (required for per-project Databricks token authentication) |
| rbac.enabled | bool | `false` | Should RBAC resources (ClusterRole/ClusterRoleBinding) be created for flyteconnector |
| rbac.rules | list | `[{"apiGroups":[""],"resources":["secrets"],"verbs":["get"]}]` | Rules for the ClusterRole created for flyteconnector |
| readinessProbe | object | `{"grpc":{"port":8000},"initialDelaySeconds":1,"periodSeconds":3}` | https://kubernetes.io/blog/2022/05/13/grpc-probes-now-in-beta/#trying-the-feature-out |
| replicaCount | int | `1` | Replicas count for flyteconnector deployment |
| resources | object | `{"limits":{"cpu":"500m","ephemeral-storage":"200Mi","memory":"300Mi"},"requests":{"cpu":"500m","ephemeral-storage":"200Mi","memory":"200Mi"}}` | Default resources requests and limits for flyteconnector deployment |
| securityContext | object | `{"allowPrivilegeEscalation":false}` | Security context for container |
| service | object | `{"annotations":{"projectcontour.io/upstream-protocol.h2c":"grpc"},"type":"ClusterIP"}` | Service settings for flyteconnector |
| serviceAccount | object | `{"annotations":{},"create":true,"imagePullSecrets":[]}` | Configuration for service accounts for flyteconnector |
| serviceAccount.annotations | object | `{}` | Annotations for ServiceAccount attached to flyteconnector pods |
| serviceAccount.create | bool | `true` | Should a service account be created for flyteconnector |
| serviceAccount.imagePullSecrets | list | `[]` | ImagePullSecrets to automatically assign to the service account |
| tolerations | list | `[]` | tolerations for flyteconnector deployment |
