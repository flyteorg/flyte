# Knative-Serving Helm Chart by Deeploy

The Helm Chart installs [Knative Serving](https://knative.dev/docs/#knative-serving) as close as possible to the original installation scripts. For the convenience of our users, it includes the required configuration needed to work with [KServe](https://kserve.github.io/website/) and [Deeploy](https://deeploy.ml/) out of the box.

## Installing the Chart

Before the chart can be installed the repo needs to be added to Helm, run the following commands to add the repo.

```
helm repo add deeploy-knative-serving https://deeploy-knative-serving-charts.storage.googleapis.com/
helm repo update
```

You can install the helm chart using the following command:

```
helm install knative-serving deeploy-knative-serving/knative-serving --namespace knative-serving --create namespace \
    --version 1.18.1
```
