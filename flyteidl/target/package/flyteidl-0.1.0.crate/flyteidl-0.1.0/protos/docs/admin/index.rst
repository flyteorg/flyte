Flyte Admin Service entities
============================

These are the control plane entities that can be used to communicate with the
FlyteAdmin service over gRPC or REST. The endpoint specification is defined in the
`Admin raw protos <https://github.com/flyteorg/flyteidl/blob/master/protos/flyteidl/admin>`__

.. toctree::
  :maxdepth: 1
  :caption: admin
  :name: admintoc

  admin
