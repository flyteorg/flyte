Flyte Task Plugins
==================

These protocol buffer specifications provide information about the various Task
Plugins available in the Flyte system.

`Plugins raw protos <https://github.com/flyteorg/flyteidl/blob/master/protos/flyteidl/plugins>`__

.. toctree::
  :maxdepth: 1
  :caption: plugins
  :name: pluginstoc

  plugins
