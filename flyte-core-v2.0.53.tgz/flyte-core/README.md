# flyte-core

![Version: 0.1.0](https://img.shields.io/badge/Version-0.1.0-informational?style=flat-square) ![Type: application](https://img.shields.io/badge/Type-application-informational?style=flat-square)

Distributed Flyte 2 core services

## Requirements

| Repository | Name | Version |
|------------|------|---------|
| file://../flyteconnector | flyteconnector | v2.0.0 |

## Values

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| commonAnnotations | object | `{}` |  |
| commonLabels | object | `{}` |  |
| components.actions.affinity | object | `{}` |  |
| components.actions.args[0] | string | `"--component"` |  |
| components.actions.args[1] | string | `"actions"` |  |
| components.actions.args[2] | string | `"--config"` |  |
| components.actions.args[3] | string | `"/etc/flyte/config.d/*.yaml"` |  |
| components.actions.autoscaling | object | `{"behavior":{},"enabled":false,"maxReplicas":10,"metrics":[],"minReplicas":1,"targetCPUUtilizationPercentage":80,"targetMemoryUtilizationPercentage":null}` | Opt-in horizontal autoscaling. Resource utilization requires resource requests. |
| components.actions.autoscaling.behavior | object | `{}` | Optional autoscaling/v2 scaleUp and scaleDown policies. |
| components.actions.autoscaling.metrics | list | `[]` | Additional autoscaling/v2 metrics (Pods, Object, External, or Resource). |
| components.actions.command[0] | string | `"/usr/bin/tini"` |  |
| components.actions.command[1] | string | `"-g"` |  |
| components.actions.command[2] | string | `"--"` |  |
| components.actions.command[3] | string | `"/usr/local/bin/flyte"` |  |
| components.actions.enabled | bool | `true` |  |
| components.actions.envFrom | list | `[]` |  |
| components.actions.extraEnv | list | `[]` |  |
| components.actions.extraPodSpec | object | `{}` |  |
| components.actions.extraVolumeMounts | list | `[]` |  |
| components.actions.extraVolumes | list | `[]` |  |
| components.actions.image.pullPolicy | string | `"IfNotPresent"` |  |
| components.actions.image.repository | string | `"cr.flyte.org/flyteorg/flyte-binary-v2"` |  |
| components.actions.image.tag | string | `"latest"` |  |
| components.actions.initContainers | list | `[]` |  |
| components.actions.livenessProbe | object | `{}` |  |
| components.actions.nodeSelector | object | `{}` |  |
| components.actions.podAnnotations | object | `{}` |  |
| components.actions.podDisruptionBudget.enabled | bool | `false` |  |
| components.actions.podDisruptionBudget.maxUnavailable | int | `1` |  |
| components.actions.podDisruptionBudget.minAvailable | string | `nil` |  |
| components.actions.podDisruptionBudget.unhealthyPodEvictionPolicy | string | `""` | Unhealthy pod eviction policy: IfHealthyBudget or AlwaysAllow. Empty uses the Kubernetes default. |
| components.actions.podLabels | object | `{}` |  |
| components.actions.podSecurityContext | object | `{}` |  |
| components.actions.priorityClassName | string | `""` |  |
| components.actions.readinessProbe | object | `{}` |  |
| components.actions.replicaCount | int | `1` |  |
| components.actions.resources | object | `{}` |  |
| components.actions.securityContext.allowPrivilegeEscalation | bool | `false` |  |
| components.actions.securityContext.capabilities.drop[0] | string | `"ALL"` |  |
| components.actions.service.annotations | object | `{}` |  |
| components.actions.service.clusterIP | string | `""` |  |
| components.actions.service.labels | object | `{}` |  |
| components.actions.service.type | string | `"ClusterIP"` |  |
| components.actions.serviceAccountName | string | `""` |  |
| components.actions.sidecars | list | `[]` |  |
| components.actions.startupProbe | object | `{}` |  |
| components.actions.strategy | object | `{}` |  |
| components.actions.tolerations | list | `[]` |  |
| components.actions.topologySpreadConstraints | list | `[]` |  |
| components.app.affinity | object | `{}` |  |
| components.app.args[0] | string | `"--component"` |  |
| components.app.args[1] | string | `"app"` |  |
| components.app.args[2] | string | `"--config"` |  |
| components.app.args[3] | string | `"/etc/flyte/config.d/*.yaml"` |  |
| components.app.autoscaling | object | `{"behavior":{},"enabled":false,"maxReplicas":10,"metrics":[],"minReplicas":1,"targetCPUUtilizationPercentage":80,"targetMemoryUtilizationPercentage":null}` | Opt-in horizontal autoscaling. Resource utilization requires resource requests. |
| components.app.autoscaling.behavior | object | `{}` | Optional autoscaling/v2 scaleUp and scaleDown policies. |
| components.app.autoscaling.metrics | list | `[]` | Additional autoscaling/v2 metrics (Pods, Object, External, or Resource). |
| components.app.command[0] | string | `"/usr/bin/tini"` |  |
| components.app.command[1] | string | `"-g"` |  |
| components.app.command[2] | string | `"--"` |  |
| components.app.command[3] | string | `"/usr/local/bin/flyte"` |  |
| components.app.enabled | bool | `false` |  |
| components.app.envFrom | list | `[]` |  |
| components.app.extraEnv | list | `[]` |  |
| components.app.extraPodSpec | object | `{}` |  |
| components.app.extraVolumeMounts | list | `[]` |  |
| components.app.extraVolumes | list | `[]` |  |
| components.app.image.pullPolicy | string | `"IfNotPresent"` |  |
| components.app.image.repository | string | `"cr.flyte.org/flyteorg/flyte-binary-v2"` |  |
| components.app.image.tag | string | `"latest"` |  |
| components.app.initContainers | list | `[]` |  |
| components.app.livenessProbe | object | `{}` |  |
| components.app.nodeSelector | object | `{}` |  |
| components.app.podAnnotations | object | `{}` |  |
| components.app.podDisruptionBudget.enabled | bool | `false` |  |
| components.app.podDisruptionBudget.maxUnavailable | int | `1` |  |
| components.app.podDisruptionBudget.minAvailable | string | `nil` |  |
| components.app.podDisruptionBudget.unhealthyPodEvictionPolicy | string | `""` | Unhealthy pod eviction policy: IfHealthyBudget or AlwaysAllow. Empty uses the Kubernetes default. |
| components.app.podLabels | object | `{}` |  |
| components.app.podSecurityContext | object | `{}` |  |
| components.app.priorityClassName | string | `""` |  |
| components.app.readinessProbe | object | `{}` |  |
| components.app.replicaCount | int | `1` |  |
| components.app.resources | object | `{}` |  |
| components.app.securityContext.allowPrivilegeEscalation | bool | `false` |  |
| components.app.securityContext.capabilities.drop[0] | string | `"ALL"` |  |
| components.app.service.annotations | object | `{}` |  |
| components.app.service.clusterIP | string | `""` |  |
| components.app.service.labels | object | `{}` |  |
| components.app.service.type | string | `"ClusterIP"` |  |
| components.app.serviceAccountName | string | `""` |  |
| components.app.sidecars | list | `[]` |  |
| components.app.startupProbe | object | `{}` |  |
| components.app.strategy | object | `{}` |  |
| components.app.tolerations | list | `[]` |  |
| components.app.topologySpreadConstraints | list | `[]` |  |
| components.cache.affinity | object | `{}` |  |
| components.cache.args[0] | string | `"--component"` |  |
| components.cache.args[1] | string | `"cache"` |  |
| components.cache.args[2] | string | `"--config"` |  |
| components.cache.args[3] | string | `"/etc/flyte/config.d/*.yaml"` |  |
| components.cache.autoscaling | object | `{"behavior":{},"enabled":false,"maxReplicas":10,"metrics":[],"minReplicas":1,"targetCPUUtilizationPercentage":80,"targetMemoryUtilizationPercentage":null}` | Opt-in horizontal autoscaling. Resource utilization requires resource requests. |
| components.cache.autoscaling.behavior | object | `{}` | Optional autoscaling/v2 scaleUp and scaleDown policies. |
| components.cache.autoscaling.metrics | list | `[]` | Additional autoscaling/v2 metrics (Pods, Object, External, or Resource). |
| components.cache.command[0] | string | `"/usr/bin/tini"` |  |
| components.cache.command[1] | string | `"-g"` |  |
| components.cache.command[2] | string | `"--"` |  |
| components.cache.command[3] | string | `"/usr/local/bin/flyte"` |  |
| components.cache.enabled | bool | `true` |  |
| components.cache.envFrom | list | `[]` |  |
| components.cache.extraEnv | list | `[]` |  |
| components.cache.extraPodSpec | object | `{}` |  |
| components.cache.extraVolumeMounts | list | `[]` |  |
| components.cache.extraVolumes | list | `[]` |  |
| components.cache.image.pullPolicy | string | `"IfNotPresent"` |  |
| components.cache.image.repository | string | `"cr.flyte.org/flyteorg/flyte-binary-v2"` |  |
| components.cache.image.tag | string | `"latest"` |  |
| components.cache.initContainers | list | `[]` |  |
| components.cache.livenessProbe | object | `{}` |  |
| components.cache.nodeSelector | object | `{}` |  |
| components.cache.podAnnotations | object | `{}` |  |
| components.cache.podDisruptionBudget.enabled | bool | `false` |  |
| components.cache.podDisruptionBudget.maxUnavailable | int | `1` |  |
| components.cache.podDisruptionBudget.minAvailable | string | `nil` |  |
| components.cache.podDisruptionBudget.unhealthyPodEvictionPolicy | string | `""` | Unhealthy pod eviction policy: IfHealthyBudget or AlwaysAllow. Empty uses the Kubernetes default. |
| components.cache.podLabels | object | `{}` |  |
| components.cache.podSecurityContext | object | `{}` |  |
| components.cache.priorityClassName | string | `""` |  |
| components.cache.readinessProbe | object | `{}` |  |
| components.cache.replicaCount | int | `1` |  |
| components.cache.resources | object | `{}` |  |
| components.cache.securityContext.allowPrivilegeEscalation | bool | `false` |  |
| components.cache.securityContext.capabilities.drop[0] | string | `"ALL"` |  |
| components.cache.service.annotations | object | `{}` |  |
| components.cache.service.clusterIP | string | `""` |  |
| components.cache.service.labels | object | `{}` |  |
| components.cache.service.type | string | `"ClusterIP"` |  |
| components.cache.serviceAccountName | string | `""` |  |
| components.cache.sidecars | list | `[]` |  |
| components.cache.startupProbe | object | `{}` |  |
| components.cache.strategy | object | `{}` |  |
| components.cache.tolerations | list | `[]` |  |
| components.cache.topologySpreadConstraints | list | `[]` |  |
| components.dataproxy.affinity | object | `{}` |  |
| components.dataproxy.args[0] | string | `"--component"` |  |
| components.dataproxy.args[1] | string | `"dataproxy"` |  |
| components.dataproxy.args[2] | string | `"--config"` |  |
| components.dataproxy.args[3] | string | `"/etc/flyte/config.d/*.yaml"` |  |
| components.dataproxy.autoscaling | object | `{"behavior":{},"enabled":false,"maxReplicas":10,"metrics":[],"minReplicas":1,"targetCPUUtilizationPercentage":80,"targetMemoryUtilizationPercentage":null}` | Opt-in horizontal autoscaling. Resource utilization requires resource requests. |
| components.dataproxy.autoscaling.behavior | object | `{}` | Optional autoscaling/v2 scaleUp and scaleDown policies. |
| components.dataproxy.autoscaling.metrics | list | `[]` | Additional autoscaling/v2 metrics (Pods, Object, External, or Resource). |
| components.dataproxy.command[0] | string | `"/usr/bin/tini"` |  |
| components.dataproxy.command[1] | string | `"-g"` |  |
| components.dataproxy.command[2] | string | `"--"` |  |
| components.dataproxy.command[3] | string | `"/usr/local/bin/flyte"` |  |
| components.dataproxy.enabled | bool | `true` |  |
| components.dataproxy.envFrom | list | `[]` |  |
| components.dataproxy.extraEnv | list | `[]` |  |
| components.dataproxy.extraPodSpec | object | `{}` |  |
| components.dataproxy.extraVolumeMounts | list | `[]` |  |
| components.dataproxy.extraVolumes | list | `[]` |  |
| components.dataproxy.image.pullPolicy | string | `"IfNotPresent"` |  |
| components.dataproxy.image.repository | string | `"cr.flyte.org/flyteorg/flyte-binary-v2"` |  |
| components.dataproxy.image.tag | string | `"latest"` |  |
| components.dataproxy.initContainers | list | `[]` |  |
| components.dataproxy.livenessProbe | object | `{}` |  |
| components.dataproxy.nodeSelector | object | `{}` |  |
| components.dataproxy.podAnnotations | object | `{}` |  |
| components.dataproxy.podDisruptionBudget.enabled | bool | `false` |  |
| components.dataproxy.podDisruptionBudget.maxUnavailable | int | `1` |  |
| components.dataproxy.podDisruptionBudget.minAvailable | string | `nil` |  |
| components.dataproxy.podDisruptionBudget.unhealthyPodEvictionPolicy | string | `""` | Unhealthy pod eviction policy: IfHealthyBudget or AlwaysAllow. Empty uses the Kubernetes default. |
| components.dataproxy.podLabels | object | `{}` |  |
| components.dataproxy.podSecurityContext | object | `{}` |  |
| components.dataproxy.priorityClassName | string | `""` |  |
| components.dataproxy.readinessProbe | object | `{}` |  |
| components.dataproxy.replicaCount | int | `1` |  |
| components.dataproxy.resources | object | `{}` |  |
| components.dataproxy.securityContext.allowPrivilegeEscalation | bool | `false` |  |
| components.dataproxy.securityContext.capabilities.drop[0] | string | `"ALL"` |  |
| components.dataproxy.service.annotations | object | `{}` |  |
| components.dataproxy.service.clusterIP | string | `""` |  |
| components.dataproxy.service.labels | object | `{}` |  |
| components.dataproxy.service.type | string | `"ClusterIP"` |  |
| components.dataproxy.serviceAccountName | string | `""` |  |
| components.dataproxy.sidecars | list | `[]` |  |
| components.dataproxy.startupProbe | object | `{}` |  |
| components.dataproxy.strategy | object | `{}` |  |
| components.dataproxy.tolerations | list | `[]` |  |
| components.dataproxy.topologySpreadConstraints | list | `[]` |  |
| components.events.affinity | object | `{}` |  |
| components.events.args[0] | string | `"--component"` |  |
| components.events.args[1] | string | `"events"` |  |
| components.events.args[2] | string | `"--config"` |  |
| components.events.args[3] | string | `"/etc/flyte/config.d/*.yaml"` |  |
| components.events.autoscaling | object | `{"behavior":{},"enabled":false,"maxReplicas":10,"metrics":[],"minReplicas":1,"targetCPUUtilizationPercentage":80,"targetMemoryUtilizationPercentage":null}` | Opt-in horizontal autoscaling. Resource utilization requires resource requests. |
| components.events.autoscaling.behavior | object | `{}` | Optional autoscaling/v2 scaleUp and scaleDown policies. |
| components.events.autoscaling.metrics | list | `[]` | Additional autoscaling/v2 metrics (Pods, Object, External, or Resource). |
| components.events.command[0] | string | `"/usr/bin/tini"` |  |
| components.events.command[1] | string | `"-g"` |  |
| components.events.command[2] | string | `"--"` |  |
| components.events.command[3] | string | `"/usr/local/bin/flyte"` |  |
| components.events.enabled | bool | `true` |  |
| components.events.envFrom | list | `[]` |  |
| components.events.extraEnv | list | `[]` |  |
| components.events.extraPodSpec | object | `{}` |  |
| components.events.extraVolumeMounts | list | `[]` |  |
| components.events.extraVolumes | list | `[]` |  |
| components.events.image.pullPolicy | string | `"IfNotPresent"` |  |
| components.events.image.repository | string | `"cr.flyte.org/flyteorg/flyte-binary-v2"` |  |
| components.events.image.tag | string | `"latest"` |  |
| components.events.initContainers | list | `[]` |  |
| components.events.livenessProbe | object | `{}` |  |
| components.events.nodeSelector | object | `{}` |  |
| components.events.podAnnotations | object | `{}` |  |
| components.events.podDisruptionBudget.enabled | bool | `false` |  |
| components.events.podDisruptionBudget.maxUnavailable | int | `1` |  |
| components.events.podDisruptionBudget.minAvailable | string | `nil` |  |
| components.events.podDisruptionBudget.unhealthyPodEvictionPolicy | string | `""` | Unhealthy pod eviction policy: IfHealthyBudget or AlwaysAllow. Empty uses the Kubernetes default. |
| components.events.podLabels | object | `{}` |  |
| components.events.podSecurityContext | object | `{}` |  |
| components.events.priorityClassName | string | `""` |  |
| components.events.readinessProbe | object | `{}` |  |
| components.events.replicaCount | int | `1` |  |
| components.events.resources | object | `{}` |  |
| components.events.securityContext.allowPrivilegeEscalation | bool | `false` |  |
| components.events.securityContext.capabilities.drop[0] | string | `"ALL"` |  |
| components.events.service.annotations | object | `{}` |  |
| components.events.service.clusterIP | string | `""` |  |
| components.events.service.labels | object | `{}` |  |
| components.events.service.type | string | `"ClusterIP"` |  |
| components.events.serviceAccountName | string | `""` |  |
| components.events.sidecars | list | `[]` |  |
| components.events.startupProbe | object | `{}` |  |
| components.events.strategy | object | `{}` |  |
| components.events.tolerations | list | `[]` |  |
| components.events.topologySpreadConstraints | list | `[]` |  |
| components.executor.affinity | object | `{}` |  |
| components.executor.args[0] | string | `"--component"` |  |
| components.executor.args[1] | string | `"executor"` |  |
| components.executor.args[2] | string | `"--config"` |  |
| components.executor.args[3] | string | `"/etc/flyte/config.d/*.yaml"` |  |
| components.executor.command[0] | string | `"/usr/bin/tini"` |  |
| components.executor.command[1] | string | `"-g"` |  |
| components.executor.command[2] | string | `"--"` |  |
| components.executor.command[3] | string | `"/usr/local/bin/flyte"` |  |
| components.executor.enabled | bool | `true` |  |
| components.executor.envFrom | list | `[]` |  |
| components.executor.extraEnv | list | `[]` |  |
| components.executor.extraPodSpec | object | `{}` |  |
| components.executor.extraVolumeMounts | list | `[]` |  |
| components.executor.extraVolumes | list | `[]` |  |
| components.executor.image.pullPolicy | string | `"IfNotPresent"` |  |
| components.executor.image.repository | string | `"cr.flyte.org/flyteorg/flyte-binary-v2"` |  |
| components.executor.image.tag | string | `"latest"` |  |
| components.executor.initContainers | list | `[]` |  |
| components.executor.livenessProbe | object | `{}` |  |
| components.executor.nodeSelector | object | `{}` |  |
| components.executor.podAnnotations | object | `{}` |  |
| components.executor.podDisruptionBudget.enabled | bool | `false` |  |
| components.executor.podDisruptionBudget.maxUnavailable | int | `1` |  |
| components.executor.podDisruptionBudget.minAvailable | string | `nil` |  |
| components.executor.podDisruptionBudget.unhealthyPodEvictionPolicy | string | `""` | Unhealthy pod eviction policy: IfHealthyBudget or AlwaysAllow. Empty uses the Kubernetes default. |
| components.executor.podLabels | object | `{}` |  |
| components.executor.podSecurityContext | object | `{}` |  |
| components.executor.priorityClassName | string | `""` |  |
| components.executor.readinessProbe | object | `{}` |  |
| components.executor.resources | object | `{}` |  |
| components.executor.securityContext.allowPrivilegeEscalation | bool | `false` |  |
| components.executor.securityContext.capabilities.drop[0] | string | `"ALL"` |  |
| components.executor.service.annotations | object | `{}` |  |
| components.executor.service.clusterIP | string | `""` |  |
| components.executor.service.labels | object | `{}` |  |
| components.executor.service.type | string | `"ClusterIP"` |  |
| components.executor.serviceAccountName | string | `""` |  |
| components.executor.sidecars | list | `[]` |  |
| components.executor.startupProbe | object | `{}` |  |
| components.executor.strategy | object | `{}` |  |
| components.executor.tolerations | list | `[]` |  |
| components.executor.topologySpreadConstraints | list | `[]` |  |
| components.runs.affinity | object | `{}` |  |
| components.runs.args[0] | string | `"--component"` |  |
| components.runs.args[1] | string | `"runs"` |  |
| components.runs.args[2] | string | `"--config"` |  |
| components.runs.args[3] | string | `"/etc/flyte/config.d/*.yaml"` |  |
| components.runs.autoscaling | object | `{"behavior":{},"enabled":false,"maxReplicas":10,"metrics":[],"minReplicas":1,"targetCPUUtilizationPercentage":80,"targetMemoryUtilizationPercentage":null}` | Opt-in horizontal autoscaling. Resource utilization requires resource requests. |
| components.runs.autoscaling.behavior | object | `{}` | Optional autoscaling/v2 scaleUp and scaleDown policies. |
| components.runs.autoscaling.metrics | list | `[]` | Additional autoscaling/v2 metrics (Pods, Object, External, or Resource). |
| components.runs.command[0] | string | `"/usr/bin/tini"` |  |
| components.runs.command[1] | string | `"-g"` |  |
| components.runs.command[2] | string | `"--"` |  |
| components.runs.command[3] | string | `"/usr/local/bin/flyte"` |  |
| components.runs.enabled | bool | `true` |  |
| components.runs.envFrom | list | `[]` |  |
| components.runs.extraEnv | list | `[]` |  |
| components.runs.extraPodSpec | object | `{}` |  |
| components.runs.extraVolumeMounts | list | `[]` |  |
| components.runs.extraVolumes | list | `[]` |  |
| components.runs.image.pullPolicy | string | `"IfNotPresent"` |  |
| components.runs.image.repository | string | `"cr.flyte.org/flyteorg/flyte-binary-v2"` |  |
| components.runs.image.tag | string | `"latest"` |  |
| components.runs.initContainers | list | `[]` |  |
| components.runs.livenessProbe | object | `{}` |  |
| components.runs.nodeSelector | object | `{}` |  |
| components.runs.podAnnotations | object | `{}` |  |
| components.runs.podDisruptionBudget.enabled | bool | `false` |  |
| components.runs.podDisruptionBudget.maxUnavailable | int | `1` |  |
| components.runs.podDisruptionBudget.minAvailable | string | `nil` |  |
| components.runs.podDisruptionBudget.unhealthyPodEvictionPolicy | string | `""` | Unhealthy pod eviction policy: IfHealthyBudget or AlwaysAllow. Empty uses the Kubernetes default. |
| components.runs.podLabels | object | `{}` |  |
| components.runs.podSecurityContext | object | `{}` |  |
| components.runs.priorityClassName | string | `""` |  |
| components.runs.readinessProbe | object | `{}` |  |
| components.runs.replicaCount | int | `1` |  |
| components.runs.resources | object | `{}` |  |
| components.runs.securityContext.allowPrivilegeEscalation | bool | `false` |  |
| components.runs.securityContext.capabilities.drop[0] | string | `"ALL"` |  |
| components.runs.service.annotations | object | `{}` |  |
| components.runs.service.clusterIP | string | `""` |  |
| components.runs.service.labels | object | `{}` |  |
| components.runs.service.type | string | `"ClusterIP"` |  |
| components.runs.serviceAccountName | string | `""` |  |
| components.runs.sidecars | list | `[]` |  |
| components.runs.startupProbe | object | `{}` |  |
| components.runs.strategy | object | `{}` |  |
| components.runs.tolerations | list | `[]` |  |
| components.runs.topologySpreadConstraints | list | `[]` |  |
| components.secret.affinity | object | `{}` |  |
| components.secret.args[0] | string | `"--component"` |  |
| components.secret.args[1] | string | `"secret"` |  |
| components.secret.args[2] | string | `"--config"` |  |
| components.secret.args[3] | string | `"/etc/flyte/config.d/*.yaml"` |  |
| components.secret.autoscaling | object | `{"behavior":{},"enabled":false,"maxReplicas":10,"metrics":[],"minReplicas":1,"targetCPUUtilizationPercentage":80,"targetMemoryUtilizationPercentage":null}` | Opt-in horizontal autoscaling. Resource utilization requires resource requests. |
| components.secret.autoscaling.behavior | object | `{}` | Optional autoscaling/v2 scaleUp and scaleDown policies. |
| components.secret.autoscaling.metrics | list | `[]` | Additional autoscaling/v2 metrics (Pods, Object, External, or Resource). |
| components.secret.command[0] | string | `"/usr/bin/tini"` |  |
| components.secret.command[1] | string | `"-g"` |  |
| components.secret.command[2] | string | `"--"` |  |
| components.secret.command[3] | string | `"/usr/local/bin/flyte"` |  |
| components.secret.enabled | bool | `true` |  |
| components.secret.envFrom | list | `[]` |  |
| components.secret.extraEnv | list | `[]` |  |
| components.secret.extraPodSpec | object | `{}` |  |
| components.secret.extraVolumeMounts | list | `[]` |  |
| components.secret.extraVolumes | list | `[]` |  |
| components.secret.image.pullPolicy | string | `"IfNotPresent"` |  |
| components.secret.image.repository | string | `"cr.flyte.org/flyteorg/flyte-binary-v2"` |  |
| components.secret.image.tag | string | `"latest"` |  |
| components.secret.initContainers | list | `[]` |  |
| components.secret.livenessProbe | object | `{}` |  |
| components.secret.nodeSelector | object | `{}` |  |
| components.secret.podAnnotations | object | `{}` |  |
| components.secret.podDisruptionBudget.enabled | bool | `false` |  |
| components.secret.podDisruptionBudget.maxUnavailable | int | `1` |  |
| components.secret.podDisruptionBudget.minAvailable | string | `nil` |  |
| components.secret.podDisruptionBudget.unhealthyPodEvictionPolicy | string | `""` | Unhealthy pod eviction policy: IfHealthyBudget or AlwaysAllow. Empty uses the Kubernetes default. |
| components.secret.podLabels | object | `{}` |  |
| components.secret.podSecurityContext | object | `{}` |  |
| components.secret.priorityClassName | string | `""` |  |
| components.secret.readinessProbe | object | `{}` |  |
| components.secret.replicaCount | int | `1` |  |
| components.secret.resources | object | `{}` |  |
| components.secret.securityContext.allowPrivilegeEscalation | bool | `false` |  |
| components.secret.securityContext.capabilities.drop[0] | string | `"ALL"` |  |
| components.secret.service.annotations | object | `{}` |  |
| components.secret.service.clusterIP | string | `""` |  |
| components.secret.service.labels | object | `{}` |  |
| components.secret.service.type | string | `"ClusterIP"` |  |
| components.secret.serviceAccountName | string | `""` |  |
| components.secret.sidecars | list | `[]` |  |
| components.secret.startupProbe | object | `{}` |  |
| components.secret.strategy | object | `{}` |  |
| components.secret.tolerations | list | `[]` |  |
| components.secret.topologySpreadConstraints | list | `[]` |  |
| configuration.actions.recordFilterSize | int | `8388608` |  |
| configuration.actions.runService.url | string | `"{{ include \"flyte-core.componentServiceURL\" (dict \"root\" . \"component\" \"runs\") }}"` |  |
| configuration.actions.server.host | string | `"0.0.0.0"` |  |
| configuration.actions.server.port | int | `8080` |  |
| configuration.actions.watchBufferSize | int | `1000` |  |
| configuration.actions.watchWorkers | int | `100` |  |
| configuration.app.cacheTtl | string | `"30s"` |  |
| configuration.app.internalAppService.url | string | `"{{ include \"flyte-core.componentServiceURL\" (dict \"root\" . \"component\" \"app\") }}"` |  |
| configuration.app.server.host | string | `"0.0.0.0"` |  |
| configuration.app.server.port | int | `8080` |  |
| configuration.cache.heartbeatGracePeriodMultiplier | int | `3` |  |
| configuration.cache.maxReservationHeartbeat | string | `"10s"` |  |
| configuration.cache.server.host | string | `"0.0.0.0"` |  |
| configuration.cache.server.port | int | `8080` |  |
| configuration.coPilot.image.repository | string | `"cr.flyte.org/flyteorg/flyte-binary-v2"` |  |
| configuration.coPilot.image.tag | string | `"latest"` |  |
| configuration.database.connMaxLifeTime | string | `"1h"` |  |
| configuration.database.maxIdleConnections | int | `10` |  |
| configuration.database.maxOpenConnections | int | `100` |  |
| configuration.database.postgres.dbname | string | `"flyte"` |  |
| configuration.database.postgres.debug | bool | `false` |  |
| configuration.database.postgres.host | string | `"127.0.0.1"` |  |
| configuration.database.postgres.options | string | `"sslmode=disable"` |  |
| configuration.database.postgres.password | string | `""` |  |
| configuration.database.postgres.passwordPath | string | `""` |  |
| configuration.database.postgres.port | int | `5432` |  |
| configuration.database.postgres.readReplicaHost | string | `""` |  |
| configuration.database.postgres.username | string | `"postgres"` |  |
| configuration.dataproxy.download.maxExpiresIn | string | `"1h"` |  |
| configuration.dataproxy.runService.url | string | `"{{ include \"flyte-core.componentServiceURL\" (dict \"root\" . \"component\" \"runs\") }}"` |  |
| configuration.dataproxy.server.host | string | `"0.0.0.0"` |  |
| configuration.dataproxy.server.port | int | `8080` |  |
| configuration.dataproxy.upload.defaultFileNameLength | int | `20` |  |
| configuration.dataproxy.upload.maxExpiresIn | string | `"1h"` |  |
| configuration.dataproxy.upload.maxSize | string | `"100Mi"` |  |
| configuration.dataproxy.upload.storagePrefix | string | `"uploads"` |  |
| configuration.events.runService.url | string | `"{{ include \"flyte-core.componentServiceURL\" (dict \"root\" . \"component\" \"runs\") }}"` |  |
| configuration.events.server.host | string | `"0.0.0.0"` |  |
| configuration.events.server.port | int | `8080` |  |
| configuration.executor.cacheService.url | string | `"{{ include \"flyte-core.componentServiceURL\" (dict \"root\" . \"component\" \"cache\") }}"` |  |
| configuration.executor.cluster | string | `""` |  |
| configuration.executor.enableHTTP2 | bool | `false` |  |
| configuration.executor.eventsService.url | string | `"{{ include \"flyte-core.componentServiceURL\" (dict \"root\" . \"component\" \"events\") }}"` |  |
| configuration.executor.gc.interval | string | `"30m"` |  |
| configuration.executor.gc.maxTTL | string | `"1h"` |  |
| configuration.executor.healthProbePort | int | `8081` |  |
| configuration.executor.leaderElect | bool | `false` |  |
| configuration.executor.maxConcurrentReconciles | int | `512` |  |
| configuration.executor.maxSystemFailures | int | `3` |  |
| configuration.executor.metricsPort | int | `10254` |  |
| configuration.executor.metricsSecure | bool | `false` |  |
| configuration.executor.requeueDuration | string | `"10s"` |  |
| configuration.externalConfigMap | string | `""` |  |
| configuration.externalSecretRef | string | `""` |  |
| configuration.extraInlineConfigMapRefs | list | `[]` |  |
| configuration.extraInlineSecretRefs | list | `[]` |  |
| configuration.inline.plugins.k8s.co-pilot.image | string | `"{{ printf \"%s:%s\" .Values.configuration.coPilot.image.repository .Values.configuration.coPilot.image.tag }}"` |  |
| configuration.inline.plugins.k8s.default-env-vars[0]._U_EP_OVERRIDE | string | `"{{ printf \"%s:%s\" (include \"flyte-core.componentServiceHost\" (dict \"root\" . \"component\" \"actions\")) (include \"flyte-core.componentPort\" (dict \"root\" . \"component\" \"actions\")) }}"` |  |
| configuration.inline.plugins.k8s.default-env-vars[1]._U_INSECURE | string | `"true"` |  |
| configuration.inline.plugins.k8s.default-env-vars[2]._U_USE_ACTIONS | string | `"1"` |  |
| configuration.inlineConfigMap | string | `""` |  |
| configuration.inlineSecretRef | string | `""` |  |
| configuration.internalApps.baseDomain | string | `""` |  |
| configuration.internalApps.defaultEnvVars | object | `{}` |  |
| configuration.internalApps.defaultRequestTimeout | string | `"300s"` |  |
| configuration.internalApps.defaultServiceAccount | string | `""` |  |
| configuration.internalApps.enabled | bool | `true` |  |
| configuration.internalApps.ingressAppsPort | int | `0` |  |
| configuration.internalApps.maxRequestTimeout | string | `"3600s"` |  |
| configuration.internalApps.namespacedNameSuffixTemplate | string | `"{{ project }}-{{ domain }}"` |  |
| configuration.internalApps.scheme | string | `"https"` |  |
| configuration.internalApps.watchBufferSize | int | `100` |  |
| configuration.kubernetes.burst | int | `2000` |  |
| configuration.kubernetes.clusterName | string | `"flyte"` |  |
| configuration.kubernetes.kubeconfig | string | `""` |  |
| configuration.kubernetes.namespace | string | `"{{ .Release.Namespace }}"` |  |
| configuration.kubernetes.qps | int | `1000` |  |
| configuration.kubernetes.timeout | string | `"30s"` |  |
| configuration.logging.level | int | `1` |  |
| configuration.logging.showSource | bool | `true` |  |
| configuration.runs.actionsService.url | string | `"{{ include \"flyte-core.componentServiceURL\" (dict \"root\" . \"component\" \"actions\") }}"` |  |
| configuration.runs.authMetadata | object | `{}` |  |
| configuration.runs.domains[0].id | string | `"development"` |  |
| configuration.runs.domains[0].name | string | `"Development"` |  |
| configuration.runs.domains[1].id | string | `"staging"` |  |
| configuration.runs.domains[1].name | string | `"Staging"` |  |
| configuration.runs.domains[2].id | string | `"production"` |  |
| configuration.runs.domains[2].name | string | `"Production"` |  |
| configuration.runs.identityHeaders.claimsJwtHeader | string | `"X-Amzn-Oidc-Data"` |  |
| configuration.runs.identityHeaders.emailHeader | string | `""` |  |
| configuration.runs.identityHeaders.subjectHeader | string | `"X-Amzn-Oidc-Identity"` |  |
| configuration.runs.notificationBufferLimit | int | `65000` |  |
| configuration.runs.notifyRetryMaxBackoff | string | `"5s"` |  |
| configuration.runs.notifyRetryMinBackoff | string | `"50ms"` |  |
| configuration.runs.seedProjects[0] | string | `"flytesnacks"` |  |
| configuration.runs.server.host | string | `"0.0.0.0"` |  |
| configuration.runs.server.port | int | `8080` |  |
| configuration.runs.storagePrefix | string | `"s3://flyte-data"` |  |
| configuration.runs.triggerScheduler.enabled | bool | `true` |  |
| configuration.runs.triggerScheduler.executionBurst | int | `20` |  |
| configuration.runs.triggerScheduler.executionQps | int | `10` |  |
| configuration.runs.triggerScheduler.maxCatchupRunsPerLoop | int | `100` |  |
| configuration.runs.triggerScheduler.resyncInterval | string | `"30s"` |  |
| configuration.runs.trustForwardedIdentityHeaders | bool | `true` |  |
| configuration.runs.watchBufferSize | int | `100` |  |
| configuration.secret.server.host | string | `"0.0.0.0"` |  |
| configuration.secret.server.port | int | `8080` |  |
| configuration.secret.webhook.url | string | `"{{ include \"flyte-core.executorCacheServiceURL\" . }}"` |  |
| configuration.storage.metadataContainer | string | `"my-organization-flyte-container"` |  |
| configuration.storage.provider | string | `"s3"` |  |
| configuration.storage.providerConfig.azure.account | string | `"storage-account-name"` |  |
| configuration.storage.providerConfig.azure.configDomainSuffix | string | `""` |  |
| configuration.storage.providerConfig.azure.configUploadConcurrency | int | `4` |  |
| configuration.storage.providerConfig.azure.key | string | `""` |  |
| configuration.storage.providerConfig.gcs.project | string | `"my-organization-gcp-project"` |  |
| configuration.storage.providerConfig.s3.accessKey | string | `""` |  |
| configuration.storage.providerConfig.s3.authType | string | `"iam"` |  |
| configuration.storage.providerConfig.s3.disableSSL | bool | `false` |  |
| configuration.storage.providerConfig.s3.endpoint | string | `""` |  |
| configuration.storage.providerConfig.s3.region | string | `"us-east-1"` |  |
| configuration.storage.providerConfig.s3.secretKey | string | `""` |  |
| configuration.storage.providerConfig.s3.secretKeyPath | string | `""` |  |
| configuration.storage.providerConfig.s3.v2Signing | bool | `false` |  |
| configuration.webhook.cacheInvalidationPort | int | `9444` |  |
| configuration.webhook.listenPort | int | `9443` |  |
| configuration.webhook.webhookTimeout | int | `30` |  |
| console.affinity | object | `{}` |  |
| console.autoscaling | object | `{"behavior":{},"enabled":false,"maxReplicas":10,"metrics":[],"minReplicas":1,"targetCPUUtilizationPercentage":80,"targetMemoryUtilizationPercentage":null}` | Opt-in horizontal autoscaling. Resource utilization requires resource requests. |
| console.autoscaling.behavior | object | `{}` | Optional autoscaling/v2 scaleUp and scaleDown policies. |
| console.autoscaling.metrics | list | `[]` | Additional autoscaling/v2 metrics (Pods, Object, External, or Resource). |
| console.basePath | string | `"/v2"` |  |
| console.containerPort | int | `8080` |  |
| console.enabled | bool | `true` |  |
| console.env | list | `[]` |  |
| console.image.pullPolicy | string | `"IfNotPresent"` |  |
| console.image.repository | string | `"ghcr.io/unionai-oss/flyteconsole-v2"` |  |
| console.image.tag | string | `"latest"` |  |
| console.imagePullSecrets | list | `[]` |  |
| console.nodeSelector | object | `{}` |  |
| console.podAnnotations | object | `{}` |  |
| console.podDisruptionBudget.enabled | bool | `false` |  |
| console.podDisruptionBudget.maxUnavailable | int | `1` |  |
| console.podDisruptionBudget.minAvailable | string | `nil` |  |
| console.podDisruptionBudget.unhealthyPodEvictionPolicy | string | `""` | Unhealthy pod eviction policy: IfHealthyBudget or AlwaysAllow. Empty uses the Kubernetes default. |
| console.podLabels | object | `{}` |  |
| console.replicaCount | int | `1` |  |
| console.resources | object | `{}` |  |
| console.securityContext | object | `{}` |  |
| console.service.annotations | object | `{}` |  |
| console.service.port | int | `80` |  |
| console.service.type | string | `"ClusterIP"` |  |
| console.tolerations | list | `[]` |  |
| enabledPlugins.tasks.task-plugins.default-for-task-types.container | string | `"container"` |  |
| enabledPlugins.tasks.task-plugins.default-for-task-types.container_array | string | `"k8s-array"` |  |
| enabledPlugins.tasks.task-plugins.default-for-task-types.sidecar | string | `"sidecar"` |  |
| flyteconnector.enabled | bool | `false` |  |
| fullnameOverride | string | `""` |  |
| imagePullSecrets | list | `[]` |  |
| ingress.apiJwtIngress.annotations | object | `{}` |  |
| ingress.apiJwtIngress.enabled | bool | `false` |  |
| ingress.apiJwtIngress.host | string | `""` |  |
| ingress.apiJwtIngress.ingressClassName | string | `""` |  |
| ingress.apiJwtIngress.tls | list | `[]` |  |
| ingress.commonAnnotations | object | `{}` |  |
| ingress.create | bool | `false` |  |
| ingress.host | string | `""` |  |
| ingress.httpAnnotations | object | `{}` |  |
| ingress.httpExtraPaths.append | list | `[]` |  |
| ingress.httpExtraPaths.prepend | list | `[]` |  |
| ingress.httpIngressClassName | string | `""` |  |
| ingress.httpTls | list | `[]` |  |
| ingress.ingressClassName | string | `""` |  |
| ingress.labels | object | `{}` |  |
| ingress.tls | list | `[]` |  |
| ingress.wellknownIngress.annotations | object | `{}` |  |
| ingress.wellknownIngress.enabled | bool | `false` |  |
| ingress.wellknownIngress.host | string | `""` |  |
| ingress.wellknownIngress.ingressClassName | string | `""` |  |
| ingress.wellknownIngress.tls | list | `[]` |  |
| nameOverride | string | `""` |  |
| rbac.annotations | object | `{}` |  |
| rbac.create | bool | `true` |  |
| rbac.extraRules | list | `[]` |  |
| rbac.labels | object | `{}` |  |
| serviceAccount.annotations | object | `{}` |  |
| serviceAccount.create | bool | `true` |  |
| serviceAccount.labels | object | `{}` |  |
| serviceAccount.name | string | `""` |  |
| telemetry.enabled | bool | `true` | Set to false to opt out. Sets DO_NOT_TRACK=1 (https://donottrack.sh) on the backend and the console; the backend passes it on to the task and app pods it creates. |
| waitForDatabase.args | list | `[]` |  |
| waitForDatabase.command | list | `[]` |  |
| waitForDatabase.enabled | bool | `true` |  |
| waitForDatabase.image.pullPolicy | string | `"IfNotPresent"` |  |
| waitForDatabase.image.repository | string | `"postgres"` |  |
| waitForDatabase.image.tag | string | `"15-alpine"` |  |
| waitForDatabase.resources | object | `{}` |  |
| waitForDatabase.securityContext | object | `{}` |  |

